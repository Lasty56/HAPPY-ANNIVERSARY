let pin = "";
const correctPin = "0211";

function press(num){ if(pin.length<4){pin+=num; updateDisplay();} }
function updateDisplay(){ document.getElementById("display").textContent = "•".repeat(pin.length); }
function clearPin(){ pin=""; updateDisplay(); }
function checkPin(){ 
  if(pin===correctPin){ showScreen('letter'); } 
  else{ alert("Wrong PIN 💔"); clearPin(); } 
}
function showScreen(id){
  document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}
function goTo(id){ showScreen(id); }
